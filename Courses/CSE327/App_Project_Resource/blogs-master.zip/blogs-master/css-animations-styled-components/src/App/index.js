import React from 'react';
// import Box from './styles/Box'
// import Trigger from './styles/Trigger';

import Final from '../Final';

export class App extends React.Component {
  render() {
    return (
      <Final />
      // <Trigger>
      //   <Box />
      // </Trigger>
    );
  }
}

export default App;
