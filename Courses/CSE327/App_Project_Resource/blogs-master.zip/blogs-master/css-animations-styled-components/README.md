# CSS Animations with Styled Components

Source code for blog about animating React components with styled-components, CSS transitions, keyframes, and animations.
